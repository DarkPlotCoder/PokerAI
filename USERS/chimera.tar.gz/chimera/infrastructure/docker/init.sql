-- Project Chimera - Database Schema
-- PostgreSQL initialization script

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- ─── Agents Table ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS agents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    agent_type VARCHAR(64) NOT NULL,
    elo_rating FLOAT DEFAULT 1200.0,
    wins INTEGER DEFAULT 0,
    losses INTEGER DEFAULT 0,
    ties INTEGER DEFAULT 0,
    hands_played INTEGER DEFAULT 0,
    total_profit BIGINT DEFAULT 0,
    vpip FLOAT DEFAULT 0.0,
    pfr FLOAT DEFAULT 0.0,
    aggression_factor FLOAT DEFAULT 1.0,
    bluff_frequency FLOAT DEFAULT 0.15,
    config JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Games Table ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS games (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_type VARCHAR(32) DEFAULT 'heads_up',
    num_players INTEGER NOT NULL,
    small_blind INTEGER NOT NULL,
    big_blind INTEGER NOT NULL,
    starting_stack INTEGER NOT NULL,
    status VARCHAR(32) DEFAULT 'active',
    hand_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- ─── Hands Table ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS hands (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID REFERENCES games(id) ON DELETE CASCADE,
    hand_number INTEGER NOT NULL,
    stage_reached VARCHAR(32),
    pot_size INTEGER DEFAULT 0,
    community_cards JSONB DEFAULT '[]',
    winners JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Actions Table ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hand_id UUID REFERENCES hands(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES agents(id),
    action_type VARCHAR(32) NOT NULL,
    amount INTEGER DEFAULT 0,
    stage VARCHAR(32) NOT NULL,
    pot_before INTEGER DEFAULT 0,
    stack_before INTEGER DEFAULT 0,
    hand_strength FLOAT,
    equity FLOAT,
    expected_value FLOAT,
    confidence FLOAT,
    reasoning TEXT,
    decision_time_ms FLOAT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Tournaments Table ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tournaments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(256) NOT NULL,
    num_hands INTEGER DEFAULT 0,
    participants JSONB DEFAULT '[]',
    final_standings JSONB DEFAULT '[]',
    duration_seconds FLOAT DEFAULT 0.0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Agent ELO History ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS elo_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    elo_before FLOAT NOT NULL,
    elo_after FLOAT NOT NULL,
    elo_change FLOAT NOT NULL,
    game_type VARCHAR(32),
    opponent_ids JSONB DEFAULT '[]',
    tournament_id UUID REFERENCES tournaments(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── CFR Training History ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cfr_training (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    variant VARCHAR(32) NOT NULL,
    iteration INTEGER NOT NULL,
    exploitability FLOAT NOT NULL,
    nash_distance FLOAT NOT NULL,
    num_info_sets INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── RL Training History ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rl_training (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    algorithm VARCHAR(32) NOT NULL,
    epoch INTEGER NOT NULL,
    policy_loss FLOAT,
    value_loss FLOAT,
    entropy FLOAT,
    reward FLOAT,
    win_rate FLOAT,
    epsilon FLOAT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Opponent Models ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS opponent_models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id VARCHAR(128) UNIQUE NOT NULL,
    name VARCHAR(128),
    hands_seen INTEGER DEFAULT 0,
    vpip FLOAT DEFAULT 0.0,
    pfr FLOAT DEFAULT 0.0,
    aggression_factor FLOAT DEFAULT 1.0,
    bluff_frequency FLOAT DEFAULT 0.15,
    profile VARCHAR(64) DEFAULT 'Unknown',
    stats JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Indexes ────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_agents_elo ON agents(elo_rating DESC);
CREATE INDEX IF NOT EXISTS idx_hands_game_id ON hands(game_id);
CREATE INDEX IF NOT EXISTS idx_actions_hand_id ON actions(hand_id);
CREATE INDEX IF NOT EXISTS idx_actions_agent_id ON actions(agent_id);
CREATE INDEX IF NOT EXISTS idx_elo_history_agent ON elo_history(agent_id);
CREATE INDEX IF NOT EXISTS idx_cfr_training_agent ON cfr_training(agent_id);
CREATE INDEX IF NOT EXISTS idx_rl_training_agent ON rl_training(agent_id);
CREATE INDEX IF NOT EXISTS idx_tournaments_created ON tournaments(created_at DESC);

-- ─── Functions ───────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_agents_updated_at
    BEFORE UPDATE ON agents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_opponent_models_updated_at
    BEFORE UPDATE ON opponent_models
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── Views ───────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW agent_leaderboard AS
SELECT
    id,
    name,
    agent_type,
    elo_rating,
    wins,
    losses,
    ties,
    hands_played,
    total_profit,
    CASE WHEN (wins + losses + ties) > 0
        THEN wins::FLOAT / (wins + losses + ties)
        ELSE 0
    END AS win_rate,
    CASE WHEN hands_played > 0
        THEN (total_profit::FLOAT / 100) / hands_played * 100
        ELSE 0
    END AS bb_per_100,
    vpip,
    pfr,
    aggression_factor,
    created_at
FROM agents
ORDER BY elo_rating DESC;

COMMENT ON TABLE agents IS 'AI agent registry with performance statistics';
COMMENT ON TABLE hands IS 'Individual hand records with community cards and outcomes';
COMMENT ON TABLE actions IS 'Every action taken with full XAI metadata';
COMMENT ON TABLE tournaments IS 'Tournament results with ELO changes';
