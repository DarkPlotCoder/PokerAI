"""
Project Chimera - Opponent Modeling
Tracks player statistics and builds opponent profiles.
Implements: VPIP, PFR, AF, Bluff Frequency tracking
"""
from __future__ import annotations
import math
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum


class PlayerProfile(str, Enum):
    TIGHT_PASSIVE = "Tight Passive (Rock)"
    TIGHT_AGGRESSIVE = "Tight Aggressive (TAG)"
    LOOSE_PASSIVE = "Loose Passive (Calling Station)"
    LOOSE_AGGRESSIVE = "Loose Aggressive (LAG)"
    UNKNOWN = "Unknown"


@dataclass
class OpponentStats:
    player_id: str
    name: str = "Unknown"

    # Core stats
    hands_seen: int = 0
    hands_voluntarily_entered: int = 0
    preflop_raises: int = 0
    postflop_bets: int = 0
    postflop_calls: int = 0
    postflop_checks: int = 0
    postflop_folds: int = 0

    # Advanced stats
    three_bet_attempts: int = 0
    three_bet_opportunities: int = 0
    fold_to_3bet: int = 0
    fold_to_3bet_opportunities: int = 0
    cbet_attempts: int = 0
    cbet_opportunities: int = 0
    fold_to_cbet: int = 0
    fold_to_cbet_opportunities: int = 0

    # Bluff tracking
    showdown_bluffs: int = 0
    showdown_total: int = 0

    # Profit tracking
    total_profit: int = 0
    hands_with_profit: int = 0

    # Action sequences
    action_history: List[Dict] = field(default_factory=list)

    @property
    def vpip(self) -> float:
        """Voluntarily Put money In Pot"""
        if self.hands_seen == 0:
            return 0.0
        return self.hands_voluntarily_entered / self.hands_seen

    @property
    def pfr(self) -> float:
        """Pre-Flop Raise percentage"""
        if self.hands_seen == 0:
            return 0.0
        return self.preflop_raises / self.hands_seen

    @property
    def aggression_factor(self) -> float:
        """(Bets + Raises) / Calls"""
        if self.postflop_calls == 0:
            return float(self.postflop_bets) if self.postflop_bets > 0 else 1.0
        return self.postflop_bets / self.postflop_calls

    @property
    def fold_frequency(self) -> float:
        """Post-flop fold frequency"""
        total = self.postflop_folds + self.postflop_calls + self.postflop_bets
        if total == 0:
            return 0.0
        return self.postflop_folds / total

    @property
    def bluff_frequency(self) -> float:
        """Estimated bluff frequency from showdowns"""
        if self.showdown_total == 0:
            return 0.15  # Prior estimate
        return self.showdown_bluffs / self.showdown_total

    @property
    def three_bet_frequency(self) -> float:
        if self.three_bet_opportunities == 0:
            return 0.0
        return self.three_bet_attempts / self.three_bet_opportunities

    @property
    def fold_to_3bet_frequency(self) -> float:
        if self.fold_to_3bet_opportunities == 0:
            return 0.0
        return self.fold_to_3bet / self.fold_to_3bet_opportunities

    @property
    def cbet_frequency(self) -> float:
        if self.cbet_opportunities == 0:
            return 0.0
        return self.cbet_attempts / self.cbet_opportunities

    @property
    def fold_to_cbet_frequency(self) -> float:
        if self.fold_to_cbet_opportunities == 0:
            return 0.0
        return self.fold_to_cbet / self.fold_to_cbet_opportunities

    @property
    def profile(self) -> PlayerProfile:
        """Classify player based on VPIP/PFR/AF"""
        vpip = self.vpip
        pfr = self.pfr
        af = self.aggression_factor

        if self.hands_seen < 20:
            return PlayerProfile.UNKNOWN

        loose_threshold = 0.27
        passive_threshold = 2.0

        is_loose = vpip > loose_threshold
        is_aggressive = af > passive_threshold

        if is_loose and is_aggressive:
            return PlayerProfile.LOOSE_AGGRESSIVE
        elif is_loose and not is_aggressive:
            return PlayerProfile.LOOSE_PASSIVE
        elif not is_loose and is_aggressive:
            return PlayerProfile.TIGHT_AGGRESSIVE
        else:
            return PlayerProfile.TIGHT_PASSIVE

    @property
    def sample_size_confidence(self) -> float:
        """Confidence in stats based on sample size"""
        return min(1.0, self.hands_seen / 100)

    def recommended_strategy(self) -> str:
        """Get counter-strategy recommendation"""
        profile = self.profile
        strategies = {
            PlayerProfile.TIGHT_PASSIVE: (
                "Steal blinds frequently. "
                "Value bet thin. "
                "Rarely bluff (they fold too much). "
                "Don't over-call their bets."
            ),
            PlayerProfile.TIGHT_AGGRESSIVE: (
                "Respect their raises (strong range). "
                "3-bet or fold vs their opens. "
                "Don't call with medium hands. "
                "Look for post-flop spots vs their c-bets."
            ),
            PlayerProfile.LOOSE_PASSIVE: (
                "Value bet more (they call too much). "
                "Avoid bluffing (they don't fold). "
                "Extract max value with strong hands. "
                "Reduce bluff frequency to near zero."
            ),
            PlayerProfile.LOOSE_AGGRESSIVE: (
                "Tighten up and let them bluff off chips. "
                "Trap with strong hands. "
                "Don't re-bluff - call more with value. "
                "Use check-raise as a trap line."
            ),
            PlayerProfile.UNKNOWN: "Gather more data before adjusting strategy."
        }
        return strategies.get(profile, "Continue data collection.")

    def to_dict(self) -> dict:
        return {
            'player_id': self.player_id,
            'name': self.name,
            'hands_seen': self.hands_seen,
            'vpip': round(self.vpip, 4),
            'pfr': round(self.pfr, 4),
            'aggression_factor': round(self.aggression_factor, 4),
            'fold_frequency': round(self.fold_frequency, 4),
            'bluff_frequency': round(self.bluff_frequency, 4),
            'three_bet_frequency': round(self.three_bet_frequency, 4),
            'fold_to_3bet': round(self.fold_to_3bet_frequency, 4),
            'cbet_frequency': round(self.cbet_frequency, 4),
            'fold_to_cbet': round(self.fold_to_cbet_frequency, 4),
            'profile': self.profile.value,
            'sample_size_confidence': round(self.sample_size_confidence, 4),
            'total_profit': self.total_profit,
            'recommended_strategy': self.recommended_strategy(),
            'stats_breakdown': {
                'total_bets_raises': self.postflop_bets,
                'total_calls': self.postflop_calls,
                'total_folds': self.postflop_folds,
                'preflop_raises': self.preflop_raises,
                'showdown_bluffs': self.showdown_bluffs,
                'showdowns': self.showdown_total
            }
        }


class OpponentModelingSystem:
    """
    Centralized opponent modeling system.
    Tracks all players and provides adaptive strategy recommendations.
    """

    def __init__(self):
        self.player_models: Dict[str, OpponentStats] = {}
        self.global_stats: Dict[str, Any] = {
            'total_hands_tracked': 0,
            'profiles_identified': 0
        }

    def get_or_create(self, player_id: str, name: str = None) -> OpponentStats:
        if player_id not in self.player_models:
            self.player_models[player_id] = OpponentStats(
                player_id=player_id,
                name=name or player_id[:8]
            )
        elif name:
            self.player_models[player_id].name = name
        return self.player_models[player_id]

    def record_preflop_action(self, player_id: str, action: str,
                               voluntarily: bool, is_raise: bool):
        model = self.get_or_create(player_id)
        model.hands_seen += 1
        if voluntarily:
            model.hands_voluntarily_entered += 1
        if is_raise:
            model.preflop_raises += 1
        model.action_history.append({
            'street': 'preflop', 'action': action, 'voluntary': voluntarily
        })

    def record_postflop_action(self, player_id: str, action: str, street: str):
        model = self.get_or_create(player_id)
        action_lower = action.lower()
        if action_lower in ('bet', 'raise', 'all_in'):
            model.postflop_bets += 1
        elif action_lower == 'call':
            model.postflop_calls += 1
        elif action_lower in ('check',):
            model.postflop_checks += 1
        elif action_lower == 'fold':
            model.postflop_folds += 1
        model.action_history.append({'street': street, 'action': action})

    def record_showdown(self, player_id: str, was_bluff: bool):
        model = self.get_or_create(player_id)
        model.showdown_total += 1
        if was_bluff:
            model.showdown_bluffs += 1

    def update_from_game_state(self, game_state: Dict):
        """Update models from game state action history"""
        stage = game_state.get('stage', 'preflop')
        actions = game_state.get('action_history', [])

        for action_record in actions:
            player_id = action_record.get('player_id')
            action = action_record.get('action', '')
            action_stage = action_record.get('stage', 'preflop')

            if not player_id:
                continue

            is_voluntary = action not in ('small_blind', 'big_blind', 'fold')
            is_raise = action in ('raise', 'all_in')

            if action_stage == 'preflop':
                self.record_preflop_action(player_id, action, is_voluntary, is_raise)
            else:
                self.record_postflop_action(player_id, action, action_stage)

    def get_player_model(self, player_id: str) -> Optional[Dict]:
        model = self.player_models.get(player_id)
        return model.to_dict() if model else None

    def get_all_models(self) -> List[Dict]:
        return [m.to_dict() for m in self.player_models.values()]

    def get_exploitative_strategy(self, player_id: str,
                                   current_action: str = 'call') -> Dict[str, Any]:
        """Get exploitative strategy against a specific opponent"""
        model = self.player_models.get(player_id)
        if not model:
            return {'recommendation': 'Unknown opponent', 'adjustments': {}}

        adjustments = {}

        # VPIP-based adjustments
        if model.vpip > 0.35:  # Loose player
            adjustments['value_bet_more'] = True
            adjustments['bluff_less'] = True
            adjustments['call_wider'] = False
        else:  # Tight player
            adjustments['steal_more'] = True
            adjustments['respect_bets'] = True

        # AF-based adjustments
        if model.aggression_factor > 3.0:  # Very aggressive
            adjustments['trap_more'] = True
            adjustments['call_down_more'] = True
        elif model.aggression_factor < 1.5:  # Very passive
            adjustments['bet_for_value'] = True
            adjustments['dont_bluff'] = True

        # Fold frequency adjustments
        if model.fold_frequency > 0.6:
            adjustments['bluff_more'] = True
        if model.fold_frequency < 0.3:
            adjustments['tighten_up'] = True

        return {
            'player_id': player_id,
            'profile': model.profile.value,
            'adjustments': adjustments,
            'recommendation': model.recommended_strategy(),
            'confidence': model.sample_size_confidence,
            'key_stats': {
                'vpip': round(model.vpip, 3),
                'pfr': round(model.pfr, 3),
                'af': round(model.aggression_factor, 3)
            }
        }

    def generate_range_estimate(self, player_id: str, stage: str,
                                  action: str) -> List[str]:
        """Estimate opponent's hand range based on their action"""
        model = self.player_models.get(player_id)
        profile = model.profile if model else PlayerProfile.UNKNOWN

        range_map = {
            (PlayerProfile.TIGHT_AGGRESSIVE, 'preflop', 'raise'): [
                'AA', 'KK', 'QQ', 'JJ', 'TT', 'AK', 'AQ'],
            (PlayerProfile.TIGHT_AGGRESSIVE, 'preflop', 'call'): [
                '99', '88', '77', 'AJ', 'AT', 'KQ'],
            (PlayerProfile.LOOSE_AGGRESSIVE, 'preflop', 'raise'): [
                'Any pair', 'Any ace', 'Suited connectors', 'Broadways', 'Many more'],
            (PlayerProfile.TIGHT_PASSIVE, 'preflop', 'call'): [
                'Medium pairs', 'Suited connectors', 'Broadways'],
            (PlayerProfile.LOOSE_PASSIVE, 'preflop', 'call'): [
                'Very wide range', 'Any two cards practically'],
        }

        key = (profile, stage, action)
        return range_map.get(key, ['Mixed range', 'Depends on history'])
