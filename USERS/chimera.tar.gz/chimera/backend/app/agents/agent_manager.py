"""
Project Chimera - Agent Manager
Manages all AI agents, tournaments, ELO ratings, and leaderboards
"""
from __future__ import annotations
import uuid
import time
import random
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from .base_agent import BaseAgent, AgentDecision
from .cfr_agent import CFRAgent
from .mcts_agent import MCTSAgent
from .deep_rl_agent import PPOAgent, DQNAgent, A2CAgent
from .rule_based_agent import RuleBasedAgent, RandomAgent
from .opponent_model import OpponentModelingSystem


@dataclass
class TournamentResult:
    tournament_id: str
    name: str
    num_hands: int
    participants: List[str]
    final_standings: List[Dict]
    hand_history: List[Dict]
    duration_seconds: float
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            'tournament_id': self.tournament_id,
            'name': self.name,
            'num_hands': self.num_hands,
            'participants': self.participants,
            'final_standings': self.final_standings,
            'duration_seconds': round(self.duration_seconds, 2),
            'timestamp': self.timestamp,
            'summary': self._generate_summary()
        }

    def _generate_summary(self) -> str:
        if not self.final_standings:
            return "No results"
        winner = self.final_standings[0]
        return (f"Tournament winner: {winner.get('name', 'Unknown')} "
                f"({winner.get('agent_type', '?')}) with "
                f"ELO {winner.get('elo_change', 0):+.1f} points. "
                f"{self.num_hands} hands played in "
                f"{self.duration_seconds:.1f}s.")


class AgentManager:
    """
    Central agent management system.
    Handles: agent registry, tournaments, ELO ratings, leaderboard
    """

    def __init__(self):
        self.agents: Dict[str, BaseAgent] = {}
        self.opponent_model = OpponentModelingSystem()
        self.tournaments: List[TournamentResult] = []
        self.leaderboard: List[Dict] = []
        self._initialize_default_agents()

    def _initialize_default_agents(self):
        """Create default set of agents"""
        default_agents = [
            CFRAgent(name="Chimera CFR-Vanilla", variant='vanilla',
                     training_iterations=3000),
            CFRAgent(name="Chimera CFR+", variant='cfr_plus',
                     training_iterations=3000),
            CFRAgent(name="Chimera MCCFR", variant='mccfr',
                     training_iterations=2000),
            MCTSAgent(name="Chimera MCTS", time_limit_ms=1000, max_iterations=200),
            PPOAgent(name="Chimera PPO"),
            DQNAgent(name="Chimera DQN"),
            A2CAgent(name="Chimera A2C"),
            RuleBasedAgent(name="Expert TAG", style='TAG'),
            RuleBasedAgent(name="Expert LAG", style='LAG'),
            RuleBasedAgent(name="Expert TP", style='TP'),
            RandomAgent(name="Random Baseline"),
        ]

        for agent in default_agents:
            self.agents[agent.agent_id] = agent

        self._update_leaderboard()

    def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        return self.agents.get(agent_id)

    def get_all_agents(self) -> List[Dict]:
        return [agent.get_info() for agent in self.agents.values()]

    def get_agent_decision(self, agent_id: str, game_state: Dict,
                            player_id: str) -> Optional[AgentDecision]:
        agent = self.agents.get(agent_id)
        if not agent:
            return None

        decision = agent.decide(game_state, player_id)

        # Update opponent model
        for p in game_state.get('players', []):
            if p.get('player_id') != player_id:
                self.opponent_model.get_or_create(
                    p['player_id'], p.get('name', 'Unknown'))

        return decision

    def run_quick_tournament(self, agent_ids: List[str],
                              num_hands: int = 50,
                              name: str = "Quick Tournament") -> TournamentResult:
        """Run a simulated tournament between agents"""
        start_time = time.time()
        tournament_id = str(uuid.uuid4())

        agents = [self.agents[aid] for aid in agent_ids if aid in self.agents]
        if len(agents) < 2:
            raise ValueError("Need at least 2 agents for tournament")

        # Initialize stacks
        initial_stack = 10000
        stacks = {agent.agent_id: initial_stack for agent in agents}
        hand_history = []

        # Simulate hands
        for hand_num in range(num_hands):
            # Simple hand simulation
            hand_result = self._simulate_hand(agents, stacks)
            hand_history.append(hand_result)

            # Update stacks
            for agent_id, delta in hand_result['profit_deltas'].items():
                stacks[agent_id] = max(0, stacks.get(agent_id, 0) + delta)

            # Remove busted agents
            agents = [a for a in agents if stacks.get(a.agent_id, 0) > 0]
            if len(agents) <= 1:
                break

        # Calculate final standings
        all_agents_final = [(self.agents[aid], stacks.get(aid, 0))
                             for aid in agent_ids if aid in self.agents]
        all_agents_final.sort(key=lambda x: x[1], reverse=True)

        final_standings = []
        for rank, (agent, final_stack) in enumerate(all_agents_final):
            profit = final_stack - initial_stack
            elo_change = self._calculate_elo_change(rank, len(agents))

            agent.stats.elo_rating += elo_change
            agent.stats.games_played += 1
            agent.stats.hands_played += num_hands
            agent.stats.total_profit += profit

            final_standings.append({
                'rank': rank + 1,
                'agent_id': agent.agent_id,
                'name': agent.name,
                'agent_type': agent.agent_type,
                'final_stack': final_stack,
                'profit': profit,
                'elo_rating': round(agent.stats.elo_rating, 2),
                'elo_change': round(elo_change, 2)
            })

        duration = time.time() - start_time

        result = TournamentResult(
            tournament_id=tournament_id,
            name=name,
            num_hands=hand_num + 1,
            participants=[a.agent_id for a in self.agents.values()
                          if a.agent_id in agent_ids],
            final_standings=final_standings,
            hand_history=hand_history[-10:],  # Last 10 hands
            duration_seconds=duration
        )

        self.tournaments.append(result)
        self._update_leaderboard()

        return result

    def _simulate_hand(self, agents: List[BaseAgent],
                        stacks: Dict[str, int]) -> Dict:
        """Simulate a single hand outcome"""
        if len(agents) < 2:
            return {'profit_deltas': {}}

        # Simple win probability based on agent type
        agent_strength = {
            'cfr_vanilla': 0.65, 'cfr_cfr_plus': 0.70, 'cfr_mccfr': 0.67,
            'mcts': 0.62, 'ppo': 0.60, 'dqn': 0.58, 'a2c': 0.60,
            'rule_based_tag': 0.55, 'rule_based_lag': 0.52,
            'rule_based_tp': 0.50, 'random': 0.40
        }

        # Normalize probabilities
        strengths = []
        for agent in agents:
            s = agent_strength.get(agent.agent_type, 0.5)
            s += random.gauss(0, 0.08)  # Add randomness
            strengths.append(max(0.01, s))

        total = sum(strengths)
        probs = [s / total for s in strengths]

        # Determine winner
        winner_idx = random.choices(range(len(agents)), weights=probs, k=1)[0]
        winner = agents[winner_idx]

        # Calculate pot
        ante = 100 + random.randint(0, 200)
        side_action = random.randint(0, 500)
        pot = ante * len(agents) + side_action

        # Distribute results
        deltas = {}
        for i, agent in enumerate(agents):
            if i == winner_idx:
                deltas[agent.agent_id] = pot - ante
            else:
                deltas[agent.agent_id] = -ante - random.randint(0, side_action // len(agents))

        return {
            'winner_id': winner.agent_id,
            'winner_name': winner.name,
            'pot': pot,
            'profit_deltas': deltas,
            'num_players': len(agents)
        }

    def _calculate_elo_change(self, rank: int, total: int) -> float:
        """Calculate ELO change based on tournament performance"""
        K = 32
        if total <= 1:
            return 0.0
        score = 1.0 - (rank / (total - 1))  # 1.0 for 1st, 0.0 for last
        expected = 0.5  # Simplified expected score
        return K * (score - expected)

    def _update_leaderboard(self):
        """Update global leaderboard"""
        self.leaderboard = sorted(
            [agent.get_info() for agent in self.agents.values()],
            key=lambda x: x['stats']['elo_rating'],
            reverse=True
        )
        for i, entry in enumerate(self.leaderboard):
            entry['rank'] = i + 1

    def get_leaderboard(self) -> List[Dict]:
        self._update_leaderboard()
        return self.leaderboard

    def get_tournament_history(self) -> List[Dict]:
        return [t.to_dict() for t in reversed(self.tournaments[-20:])]

    def get_agent_comparison(self, agent_ids: List[str]) -> Dict:
        """Compare multiple agents side by side"""
        comparison = []
        for agent_id in agent_ids:
            agent = self.agents.get(agent_id)
            if agent:
                comparison.append({
                    'agent_id': agent_id,
                    'name': agent.name,
                    'type': agent.agent_type,
                    'elo': agent.stats.elo_rating,
                    'win_rate': agent.stats.win_rate,
                    'hands_played': agent.stats.hands_played,
                    'total_profit': agent.stats.total_profit,
                    'bb_per_100': agent.stats.bb_per_100
                })

        return {
            'agents': comparison,
            'metrics': ['elo', 'win_rate', 'bb_per_100'],
            'best_elo': max(comparison, key=lambda x: x['elo']) if comparison else None,
            'best_winrate': max(comparison, key=lambda x: x['win_rate']) if comparison else None
        }
