"""
Project Chimera - Rule-Based & Random Agents
Implements: Tight-Aggressive, Loose-Passive, Adaptive Rule-Based, Random Baseline
"""
from __future__ import annotations
import random
import time
from typing import Dict, List, Optional
from .base_agent import BaseAgent, AgentDecision


class RuleBasedAgent(BaseAgent):
    """
    Expert rule-based poker agent.
    Implements TAG (Tight-Aggressive) strategy with position awareness.
    """

    def __init__(self, agent_id=None, name="Rule-Based Agent",
                 style: str = 'TAG'):
        self.style = style  # Set before super().__init__
        super().__init__(agent_id, name)  # TAG, LAG, TP, LP
        self._bluff_threshold = {'TAG': 0.15, 'LAG': 0.30, 'TP': 0.08, 'LP': 0.25}[style]
        self._call_threshold = {'TAG': 0.40, 'LAG': 0.25, 'TP': 0.45, 'LP': 0.30}[style]
        self._raise_threshold = {'TAG': 0.60, 'LAG': 0.45, 'TP': 0.70, 'LP': 0.55}[style]

    @property
    def agent_type(self) -> str:
        return f"rule_based_{self.style.lower()}"

    def decide(self, game_state: Dict, player_id: str) -> AgentDecision:
        start_time = time.time()

        legal_actions = game_state.get('legal_actions', [])
        legal_names = [a['action'] for a in legal_actions]
        pot = game_state.get('pot', 0)
        stage = game_state.get('stage', 'preflop')

        # Get player state
        player_stack = 0
        player_cards = []
        for p in game_state.get('players', []):
            if p.get('player_id') == player_id:
                player_stack = p.get('stack', 0)
                player_cards = p.get('hole_cards', [])
                break

        hand_strength = self._calculate_hand_strength(player_cards, game_state)
        call_amount = next((a['amount'] for a in legal_actions if a['action'] == 'call'), 0)
        pot_odds = self._calculate_pot_odds(call_amount, pot)
        equity = hand_strength * 0.85 + 0.1
        ev = self._calculate_ev(equity, pot, call_amount)

        # Determine action based on style and hand strength
        action, amount, reasoning = self._apply_strategy(
            hand_strength, equity, pot_odds, ev,
            legal_names, legal_actions, pot, stage, player_stack)

        elapsed_ms = (time.time() - start_time) * 1000

        return AgentDecision(
            action=action,
            amount=amount,
            confidence=0.75,
            reasoning=reasoning,
            hand_strength=hand_strength,
            equity=equity,
            pot_odds=pot_odds,
            expected_value=ev,
            opponent_range=self._range_estimate(stage, game_state),
            decision_time_ms=elapsed_ms,
            metadata={
                'style': self.style,
                'bluff_threshold': self._bluff_threshold,
                'call_threshold': self._call_threshold,
                'raise_threshold': self._raise_threshold
            }
        )

    def _calculate_hand_strength(self, cards: List[Dict], game_state: Dict) -> float:
        """Calculate hand strength from cards"""
        if not cards or cards[0].get('hidden', False):
            return 0.5

        rank_values = []
        suits = []
        for card in cards:
            rv = card.get('rank_value', 7)
            if rv is None:
                rank_map = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9}
                rv = rank_map.get(str(card.get('rank', '7')), 7)
            rank_values.append(rv)
            suits.append(card.get('suit', ''))

        if len(rank_values) < 2:
            return 0.5

        high, low = max(rank_values), min(rank_values)
        suited = len(set(suits)) == 1
        paired = len(set(rank_values)) == 1

        strength = (high + low - 4) / 24
        if suited:
            strength += 0.03
        if paired:
            strength += 0.20
        if high == 14:
            strength += 0.05

        # Adjust for community cards (simplified)
        community = game_state.get('community_cards', [])
        if community:
            community_ranks = [c.get('rank_value', 7) for c in community]
            matched = sum(1 for rv in rank_values if rv in community_ranks)
            strength += matched * 0.12

        return max(0.1, min(0.95, strength))

    def _apply_strategy(self, hs: float, equity: float, pot_odds: float,
                         ev: float, legal_names: List[str], legal_actions: List[Dict],
                         pot: int, stage: str, stack: int):
        """Apply style-specific strategy rules"""
        bluff = random.random() < self._bluff_threshold

        # Premium hands - always raise
        if hs >= 0.80:
            if 'raise' in legal_names:
                amt = self._get_raise_amount(legal_actions, pot, 1.0)
                return 'raise', amt, (
                    f"[{self.style}] Premium hand (strength={hs:.1%}): Value raise "
                    f"to {amt} chips. Equity {equity:.1%} >> pot odds {pot_odds:.1%}."
                )
            if 'all_in' in legal_names and stack < pot * 0.5:
                return 'all_in', stack, f"[{self.style}] Premium hand, shoving for value."

        # Strong hands - raise or call
        elif hs >= self._raise_threshold:
            if 'raise' in legal_names:
                mult = 0.7 if self.style in ('TAG', 'TP') else 0.5
                amt = self._get_raise_amount(legal_actions, pot, mult)
                return 'raise', amt, (
                    f"[{self.style}] Strong hand (strength={hs:.1%}): Raise for value. "
                    f"EV={ev:+.0f}, equity {equity:.1%}."
                )
            if 'call' in legal_names:
                return 'call', next(a['amount'] for a in legal_actions if a['action'] == 'call'), (
                    f"[{self.style}] Strong hand: Call. EV={ev:+.0f}."
                )

        # Medium hands - call if odds are right
        elif hs >= self._call_threshold:
            if equity > pot_odds + 0.05:  # Positive expected value
                if 'check' in legal_names:
                    return 'check', 0, f"[{self.style}] Medium hand: Free check, equity {equity:.1%}."
                if 'call' in legal_names:
                    return 'call', next(a['amount'] for a in legal_actions if a['action'] == 'call'), (
                        f"[{self.style}] Medium hand: Call with positive EV={ev:+.0f}."
                    )
            elif 'check' in legal_names:
                return 'check', 0, f"[{self.style}] Medium hand: Check (no clear EV edge)."

        # Weak hands - bluff or fold
        else:
            if bluff and hs < 0.25 and 'raise' in legal_names and stage in ('flop', 'turn'):
                amt = self._get_raise_amount(legal_actions, pot, 0.4)
                return 'raise', amt, (
                    f"[{self.style}] Bluff raise: hand {hs:.1%} weak but "
                    f"semi-bluffing based on {self._bluff_threshold:.0%} bluff frequency."
                )
            if 'check' in legal_names:
                return 'check', 0, f"[{self.style}] Weak hand: Check to see free card."
            return 'fold', 0, (
                f"[{self.style}] Weak hand (strength={hs:.1%}): Fold. "
                f"Pot odds {pot_odds:.1%} > equity {equity:.1%}."
            )

        # Default
        if 'check' in legal_names:
            return 'check', 0, f"[{self.style}] Default: Check."
        if 'fold' in legal_names:
            return 'fold', 0, f"[{self.style}] Default: Fold."
        return legal_names[0], 0, f"[{self.style}] Fallback action."

    def _get_raise_amount(self, legal_actions: List[Dict], pot: int, mult: float) -> int:
        for a in legal_actions:
            if a['action'] == 'raise':
                min_raise = a.get('min', 0)
                max_raise = a.get('max', min_raise)
                target = min_raise + int((max_raise - min_raise) * mult)
                return max(min_raise, min(max_raise, target))
        return 0

    def _range_estimate(self, stage: str, game_state: Dict) -> List[str]:
        style_ranges = {
            'TAG': {'preflop': ['Premium pairs', 'AK/AQ', 'Broadways'],
                    'postflop': ['Top pair+', 'Strong draws']},
            'LAG': {'preflop': ['Any pair', 'Suited connectors', 'Broadways', 'Many hands'],
                    'postflop': ['Wide range', 'Any equity']},
            'TP': {'preflop': ['Premium hands only'],
                   'postflop': ['Nut hands', 'Very strong made hands']},
            'LP': {'preflop': ['Speculative hands', 'Suited connectors'],
                   'postflop': ['Any showdown value']}
        }
        key = 'preflop' if stage == 'preflop' else 'postflop'
        return style_ranges.get(self.style, {}).get(key, ['Unknown'])


class RandomAgent(BaseAgent):
    """Random baseline agent - uniformly samples legal actions"""

    def __init__(self, agent_id=None, name="Random Agent"):
        super().__init__(agent_id, name)

    @property
    def agent_type(self) -> str:
        return "random"

    def decide(self, game_state: Dict, player_id: str) -> AgentDecision:
        start_time = time.time()

        legal_actions = game_state.get('legal_actions', [])
        pot = game_state.get('pot', 0)

        if not legal_actions:
            legal_actions = [{'action': 'fold', 'amount': 0}]

        chosen = random.choice(legal_actions)
        action = chosen['action']
        amount = chosen.get('amount', 0)
        if action == 'raise':
            min_r = chosen.get('min', 0)
            max_r = chosen.get('max', min_r)
            if max_r > min_r:
                amount = random.randint(min_r, max_r)
            else:
                amount = min_r

        elapsed_ms = (time.time() - start_time) * 1000

        return AgentDecision(
            action=action,
            amount=amount,
            confidence=1.0 / len(legal_actions),
            reasoning=(f"Random baseline: Uniformly sampled '{action}' "
                       f"from {len(legal_actions)} legal actions. "
                       f"No strategy applied - pure random policy for baseline comparison."),
            hand_strength=random.random(),
            equity=0.5,
            pot_odds=self._calculate_pot_odds(amount, pot),
            expected_value=0.0,
            opponent_range=['Unknown (random policy)'],
            decision_time_ms=elapsed_ms,
            metadata={'strategy': 'uniform_random', 'num_legal_actions': len(legal_actions)}
        )
