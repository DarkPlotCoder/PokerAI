"""
Project Chimera - Base Agent
Abstract base class for all poker AI agents
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
import time
import uuid


@dataclass
class AgentDecision:
    action: str
    amount: int
    confidence: float
    reasoning: str
    hand_strength: float
    equity: float
    pot_odds: float
    expected_value: float
    opponent_range: List[str]
    decision_time_ms: float
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            'action': self.action,
            'amount': self.amount,
            'confidence': round(self.confidence, 4),
            'reasoning': self.reasoning,
            'hand_strength': round(self.hand_strength, 4),
            'equity': round(self.equity, 4),
            'pot_odds': round(self.pot_odds, 4),
            'expected_value': round(self.expected_value, 4),
            'opponent_range': self.opponent_range,
            'decision_time_ms': round(self.decision_time_ms, 2),
            'metadata': self.metadata
        }


@dataclass
class AgentStats:
    agent_id: str
    agent_type: str
    games_played: int = 0
    hands_played: int = 0
    total_profit: int = 0
    wins: int = 0
    losses: int = 0
    ties: int = 0
    elo_rating: float = 1200.0
    vpip: float = 0.0    # Voluntarily Put money In Pot
    pfr: float = 0.0     # Pre-Flop Raise
    aggression_factor: float = 0.0
    bluff_frequency: float = 0.0
    fold_to_3bet: float = 0.0
    decision_history: List[Dict] = field(default_factory=list)

    @property
    def win_rate(self) -> float:
        total = self.wins + self.losses + self.ties
        return self.wins / total if total > 0 else 0.0

    @property
    def bb_per_100(self) -> float:
        """Big blinds won per 100 hands"""
        if self.hands_played == 0:
            return 0.0
        return (self.total_profit / 100) / self.hands_played * 100

    def to_dict(self) -> dict:
        return {
            'agent_id': self.agent_id,
            'agent_type': self.agent_type,
            'games_played': self.games_played,
            'hands_played': self.hands_played,
            'total_profit': self.total_profit,
            'wins': self.wins,
            'losses': self.losses,
            'ties': self.ties,
            'win_rate': round(self.win_rate, 4),
            'elo_rating': round(self.elo_rating, 2),
            'bb_per_100': round(self.bb_per_100, 2),
            'vpip': round(self.vpip, 4),
            'pfr': round(self.pfr, 4),
            'aggression_factor': round(self.aggression_factor, 4),
            'bluff_frequency': round(self.bluff_frequency, 4),
        }


class BaseAgent(ABC):
    """Abstract base class for all poker AI agents"""

    def __init__(self, agent_id: Optional[str] = None, name: str = "Agent"):
        self.agent_id = agent_id or str(uuid.uuid4())
        self.name = name
        self.stats = AgentStats(agent_id=self.agent_id, agent_type=self.agent_type)

    @property
    @abstractmethod
    def agent_type(self) -> str:
        """Return agent type identifier"""
        pass

    @abstractmethod
    def decide(self, game_state: Dict, player_id: str) -> AgentDecision:
        """
        Make a decision given the current game state.
        Returns AgentDecision with action and reasoning.
        """
        pass

    def _calculate_pot_odds(self, call_amount: int, pot: int) -> float:
        """Calculate pot odds"""
        if call_amount + pot == 0:
            return 0.0
        return call_amount / (call_amount + pot)

    def _calculate_ev(self, equity: float, pot: int, call_amount: int) -> float:
        """Calculate expected value"""
        ev_win = equity * pot
        ev_loss = (1 - equity) * call_amount
        return ev_win - ev_loss

    def update_stats(self, hand_result: Dict):
        """Update agent statistics after a hand"""
        self.stats.hands_played += 1
        profit = hand_result.get('profit', 0)
        self.stats.total_profit += profit
        if profit > 0:
            self.stats.wins += 1
        elif profit < 0:
            self.stats.losses += 1
        else:
            self.stats.ties += 1

    def update_elo(self, opponent_elo: float, won: bool, k_factor: float = 32):
        """Update ELO rating after a game"""
        expected = 1 / (1 + 10 ** ((opponent_elo - self.stats.elo_rating) / 400))
        actual = 1.0 if won else 0.0
        self.stats.elo_rating += k_factor * (actual - expected)

    def get_info(self) -> dict:
        return {
            'agent_id': self.agent_id,
            'name': self.name,
            'agent_type': self.agent_type,
            'stats': self.stats.to_dict()
        }
