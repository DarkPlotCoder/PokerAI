"""
Project Chimera - MCTS Agent
Monte Carlo Tree Search for Poker Decision Making
Implements: Selection (UCT), Expansion, Simulation, Backpropagation
"""
from __future__ import annotations
import math
import time
import random
import uuid
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from .base_agent import BaseAgent, AgentDecision


@dataclass
class MCTSNode:
    """A node in the Monte Carlo Tree"""
    node_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    parent: Optional['MCTSNode'] = None
    action: Optional[str] = None
    action_amount: int = 0
    children: List['MCTSNode'] = field(default_factory=list)

    # Statistics
    visits: int = 0
    total_value: float = 0.0
    wins: int = 0
    losses: int = 0
    ties: int = 0

    # Game state info
    depth: int = 0
    stage: str = 'preflop'
    pot: int = 0
    is_terminal: bool = False
    terminal_value: float = 0.0

    @property
    def value(self) -> float:
        if self.visits == 0:
            return 0.0
        return self.total_value / self.visits

    @property
    def win_rate(self) -> float:
        if self.visits == 0:
            return 0.0
        return self.wins / self.visits

    def uct_score(self, exploration_constant: float = math.sqrt(2)) -> float:
        """Upper Confidence Bound for Trees (UCT) score"""
        if self.visits == 0:
            return float('inf')
        parent_visits = self.parent.visits if self.parent else 1
        exploitation = self.value
        exploration = exploration_constant * math.sqrt(
            math.log(parent_visits) / self.visits)
        return exploitation + exploration

    def is_fully_expanded(self) -> bool:
        """Check if all possible actions have been explored"""
        return len(self.children) >= 5  # Max 5 actions in poker

    def best_child(self, exploration_constant: float = math.sqrt(2)) -> 'MCTSNode':
        """Select best child by UCT score"""
        return max(self.children, key=lambda c: c.uct_score(exploration_constant))

    def to_dict(self, max_depth: int = 3) -> dict:
        """Serialize node for visualization"""
        result = {
            'id': self.node_id,
            'action': self.action,
            'amount': self.action_amount,
            'visits': self.visits,
            'value': round(self.value, 4),
            'win_rate': round(self.win_rate, 4),
            'wins': self.wins,
            'losses': self.losses,
            'ties': self.ties,
            'depth': self.depth,
            'stage': self.stage,
            'pot': self.pot,
            'is_terminal': self.is_terminal,
            'uct_score': round(self.uct_score(), 4) if self.parent else None
        }
        if max_depth > 0 and self.children:
            result['children'] = [c.to_dict(max_depth - 1) for c in self.children[:5]]
        return result


class MCTSEngine:
    """
    Monte Carlo Tree Search engine for poker.
    Implements standard MCTS with poker-specific optimizations:
    - Information set sampling
    - Opponent modeling in rollouts
    - Stage-aware evaluation
    """

    ACTIONS = ['fold', 'check', 'call', 'raise', 'all_in']
    EXPLORATION_CONSTANT = math.sqrt(2)

    def __init__(self, time_limit_ms: int = 2000, max_iterations: int = 500):
        self.time_limit_ms = time_limit_ms
        self.max_iterations = max_iterations
        self.root: Optional[MCTSNode] = None
        self.total_simulations = 0
        self.tree_stats = {
            'max_depth': 0,
            'total_nodes': 0,
            'iterations_run': 0
        }

    def search(self, game_state: Dict, player_id: str) -> Tuple[str, int, MCTSNode]:
        """
        Run MCTS search from current game state.
        Returns (best_action, best_amount, root_node)
        """
        self.root = MCTSNode(
            stage=game_state.get('stage', 'preflop'),
            pot=game_state.get('pot', 0),
            depth=0
        )

        legal_actions = game_state.get('legal_actions', [])
        hand_strength = self._estimate_hand_strength(game_state, player_id)

        start_time = time.time()
        iterations = 0

        while (iterations < self.max_iterations and
               (time.time() - start_time) * 1000 < self.time_limit_ms):

            # Selection
            node = self._select(self.root)

            # Expansion
            if not node.is_terminal and node.visits > 0:
                node = self._expand(node, legal_actions, game_state)

            # Simulation (rollout)
            value = self._simulate(node, hand_strength, game_state)

            # Backpropagation
            self._backpropagate(node, value)

            iterations += 1

        self.total_simulations += iterations
        self.tree_stats['iterations_run'] = iterations

        # Update tree stats
        self._calculate_tree_stats(self.root)

        # Select best action
        if not self.root.children:
            return 'fold', 0, self.root

        # During play: use exploitation only (no exploration)
        best_child = max(self.root.children, key=lambda c: c.visits)
        action = best_child.action or 'fold'
        amount = best_child.action_amount

        return action, amount, self.root

    def _select(self, node: MCTSNode) -> MCTSNode:
        """Selection phase: traverse tree using UCT"""
        while node.children and not node.is_terminal:
            if not node.is_fully_expanded():
                return node
            node = node.best_child(self.EXPLORATION_CONSTANT)
        return node

    def _expand(self, node: MCTSNode, legal_actions: List[Dict],
                 game_state: Dict) -> MCTSNode:
        """Expansion phase: add new child node"""
        existing_actions = {c.action for c in node.children}
        unexplored = [a for a in legal_actions
                      if a['action'] not in existing_actions]

        if not unexplored:
            return node

        # Choose action to expand
        action_data = random.choice(unexplored)
        action_name = action_data['action']
        amount = action_data.get('amount', 0)

        child = MCTSNode(
            parent=node,
            action=action_name,
            action_amount=amount,
            depth=node.depth + 1,
            stage=game_state.get('stage', 'preflop'),
            pot=game_state.get('pot', 0) + amount,
            is_terminal=action_name == 'fold' or node.depth >= 8
        )

        node.children.append(child)
        self.tree_stats['total_nodes'] += 1
        return child

    def _simulate(self, node: MCTSNode, hand_strength: float,
                  game_state: Dict) -> float:
        """
        Simulation phase: random rollout from node.
        Returns value in [-1, 1]
        """
        if node.is_terminal:
            if node.action == 'fold':
                return -0.3 * (1 - hand_strength)
            return hand_strength * 2 - 1

        # Simulate random play-out
        stage_order = ['preflop', 'flop', 'turn', 'river']
        current_stage_idx = stage_order.index(
            node.stage) if node.stage in stage_order else 0

        pot = node.pot
        remaining_streets = 3 - current_stage_idx

        # Simulate card improvements
        equity = hand_strength
        for _ in range(remaining_streets):
            # Randomly improve or worsen hand
            equity += random.uniform(-0.15, 0.15)
            equity = max(0.05, min(0.95, equity))

        # Simulate opponent actions
        for _ in range(remaining_streets):
            opp_action = self._sample_opponent_action(equity, pot)
            if opp_action == 'fold':
                return 0.8  # Win by fold
            elif opp_action == 'raise':
                pot *= 1.5 + random.uniform(0, 0.5)

        # Final equity-based evaluation
        outcome = random.random()
        if outcome < equity:
            return min(1.0, 0.5 + equity * 0.5)  # Win
        else:
            return max(-1.0, -0.5 - (1 - equity) * 0.5)  # Loss

    def _sample_opponent_action(self, our_equity: float, pot: int) -> str:
        """Sample opponent action for simulation"""
        opp_strength = random.random()
        if opp_strength < 0.3:
            return 'fold'
        elif opp_strength < 0.7:
            return 'call'
        else:
            return 'raise'

    def _backpropagate(self, node: MCTSNode, value: float):
        """Backpropagation phase: update statistics up the tree"""
        while node is not None:
            node.visits += 1
            node.total_value += value
            if value > 0.2:
                node.wins += 1
            elif value < -0.2:
                node.losses += 1
            else:
                node.ties += 1
            node = node.parent

    def _estimate_hand_strength(self, game_state: Dict, player_id: str) -> float:
        """Estimate hand strength from available information"""
        for p in game_state.get('players', []):
            if p.get('player_id') == player_id:
                cards = p.get('hole_cards', [])
                if cards and not cards[0].get('hidden', False):
                    ranks = [c.get('rank_value', 7) for c in cards
                             if not c.get('hidden')]
                    if len(ranks) >= 2:
                        high, low = max(ranks), min(ranks)
                        suited = len(set(c.get('suit', '') for c in cards)) == 1
                        paired = len(set(ranks)) == 1
                        strength = (high + low - 4) / 24
                        strength += 0.03 if suited else 0
                        strength += 0.15 if paired else 0
                        return max(0.15, min(0.9, strength))
        return 0.5

    def _calculate_tree_stats(self, node: MCTSNode, depth: int = 0):
        """Calculate tree statistics"""
        if depth > self.tree_stats['max_depth']:
            self.tree_stats['max_depth'] = depth
        for child in node.children:
            self._calculate_tree_stats(child, depth + 1)

    def get_tree_visualization(self, max_depth: int = 3) -> Dict:
        """Get tree data for visualization"""
        if not self.root:
            return {}
        return {
            'tree': self.root.to_dict(max_depth),
            'stats': {
                'total_simulations': self.total_simulations,
                'max_depth': self.tree_stats['max_depth'],
                'total_nodes': self.tree_stats['total_nodes'],
                'iterations': self.tree_stats['iterations_run']
            }
        }


class MCTSAgent(BaseAgent):
    """MCTS-based poker agent"""

    def __init__(self, agent_id: Optional[str] = None, name: str = "MCTS Agent",
                 time_limit_ms: int = 1500, max_iterations: int = 300):
        super().__init__(agent_id, name)
        self.mcts_engine = MCTSEngine(time_limit_ms, max_iterations)
        self.last_tree = None

    @property
    def agent_type(self) -> str:
        return "mcts"

    def decide(self, game_state: Dict, player_id: str) -> AgentDecision:
        start_time = time.time()

        # Run MCTS
        action, amount, root = self.mcts_engine.search(game_state, player_id)
        self.last_tree = root

        # Get metrics
        pot = game_state.get('pot', 0)
        legal_actions = game_state.get('legal_actions', [])

        hand_strength = self.mcts_engine._estimate_hand_strength(game_state, player_id)
        call_amount = next((a['amount'] for a in legal_actions if a['action'] == 'call'), 0)
        equity = hand_strength * 0.85 + 0.1
        pot_odds = self._calculate_pot_odds(call_amount, pot)
        ev = self._calculate_ev(equity, pot, call_amount)

        # Confidence from visit distribution
        if root.children:
            total_visits = sum(c.visits for c in root.children)
            best_child = max(root.children, key=lambda c: c.visits)
            confidence = best_child.visits / total_visits if total_visits > 0 else 0.5
        else:
            confidence = 0.5

        # Generate tree stats
        tree_data = self.mcts_engine.get_tree_visualization(2)

        elapsed_ms = (time.time() - start_time) * 1000

        reasoning = (
            f"MCTS ({self.mcts_engine.tree_stats['iterations_run']} simulations): "
            f"{action.capitalize()} with {confidence:.1%} confidence. "
            f"Tree depth {self.mcts_engine.tree_stats['max_depth']}, "
            f"{self.mcts_engine.tree_stats['total_nodes']} nodes explored. "
            f"Hand strength {hand_strength:.1%}, equity {equity:.1%}, "
            f"EV={ev:+.0f}. "
            f"Best line found via UCT traversal (C={math.sqrt(2):.3f})."
        )

        return AgentDecision(
            action=action,
            amount=amount,
            confidence=confidence,
            reasoning=reasoning,
            hand_strength=hand_strength,
            equity=equity,
            pot_odds=pot_odds,
            expected_value=ev,
            opponent_range=self._get_opponent_range(game_state),
            decision_time_ms=elapsed_ms,
            metadata={
                'mcts_iterations': self.mcts_engine.tree_stats['iterations_run'],
                'tree_depth': self.mcts_engine.tree_stats['max_depth'],
                'total_nodes': self.mcts_engine.tree_stats['total_nodes'],
                'action_distribution': {
                    c.action: {'visits': c.visits, 'value': round(c.value, 4)}
                    for c in root.children
                } if root.children else {},
                'tree_data': tree_data
            }
        )

    def _get_opponent_range(self, game_state: Dict) -> List[str]:
        stage = game_state.get('stage', 'preflop')
        action_history = game_state.get('action_history', [])
        raises = sum(1 for a in action_history if a.get('action') == 'raise')

        if raises >= 2:
            return ['Strong made hands', 'Nut draws', 'Premium pairs']
        elif raises == 1:
            return ['Top pair+', 'Strong draws', 'Speculative hands']
        else:
            return ['Wide range', 'Any two cards', 'Speculative hands']

    def get_tree_visualization(self) -> Dict:
        return self.mcts_engine.get_tree_visualization()
