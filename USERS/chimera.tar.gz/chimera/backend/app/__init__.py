# Project Chimera - Multi-Agent Poker Intelligence Engine
__version__ = "1.0.0"
