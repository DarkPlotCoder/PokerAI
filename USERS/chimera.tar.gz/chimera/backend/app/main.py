"""
Project Chimera - Main FastAPI Application
Multi-Agent Poker Intelligence Engine
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import os

from .api.routes import router

app = FastAPI(
    title="Project Chimera — Multi-Agent Poker Intelligence Engine",
    description="""
    ## Advanced Poker AI Research Platform

    Implements state-of-the-art game theory algorithms:
    - **CFR** (Counterfactual Regret Minimization) - Vanilla, CFR+, Monte Carlo
    - **MCTS** (Monte Carlo Tree Search) with UCT selection
    - **Deep RL** - PPO, DQN, A2C with self-play training
    - **Rule-Based** - TAG, LAG, TP, LP expert systems
    - **Opponent Modeling** - VPIP/PFR/AF tracking with adaptive strategy

    Perfect for AI research, quantitative finance, and ML engineering interviews.
    """,
    version="1.0.0",
    contact={
        "name": "Project Chimera",
        "url": "https://github.com/chimera-poker",
    }
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router, prefix="/api/v1")


@app.get("/")
async def root():
    return {
        "project": "Project Chimera",
        "subtitle": "Multi-Agent Poker Intelligence Engine",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "api_docs": "/docs",
            "redoc": "/redoc",
            "health": "/api/v1/health",
            "agents": "/api/v1/agents",
            "leaderboard": "/api/v1/leaderboard",
            "demo": "/api/v1/demo/run"
        },
        "algorithms": [
            "Counterfactual Regret Minimization (CFR/CFR+/MCCFR)",
            "Monte Carlo Tree Search (MCTS+UCT)",
            "Proximal Policy Optimization (PPO)",
            "Deep Q-Network (DQN)",
            "Advantage Actor-Critic (A2C)",
            "Expert Rule-Based Systems (TAG/LAG/TP/LP)"
        ]
    }


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=False)
