"""
Project Chimera - Poker Engine
Complete Texas Hold'em game engine supporting heads-up, 6-max, and 9-handed
"""
from __future__ import annotations
import uuid
import random
from enum import Enum, auto
from typing import List, Optional, Dict, Any, Tuple
from dataclasses import dataclass, field
from .cards import Card, Deck, Rank, Suit
from .hand_evaluator import HandEvaluator, HandResult


class GameStage(str, Enum):
    PREFLOP = "preflop"
    FLOP = "flop"
    TURN = "turn"
    RIVER = "river"
    SHOWDOWN = "showdown"
    FINISHED = "finished"


class PlayerAction(str, Enum):
    FOLD = "fold"
    CHECK = "check"
    CALL = "call"
    RAISE = "raise"
    ALL_IN = "all_in"
    SMALL_BLIND = "small_blind"
    BIG_BLIND = "big_blind"


class PlayerStatus(str, Enum):
    ACTIVE = "active"
    FOLDED = "folded"
    ALL_IN = "all_in"
    OUT = "out"


@dataclass
class ActionRecord:
    player_id: str
    action: PlayerAction
    amount: int
    stage: GameStage
    pot_before: int
    stack_before: int

    def to_dict(self) -> dict:
        return {
            'player_id': self.player_id,
            'action': self.action.value,
            'amount': self.amount,
            'stage': self.stage.value,
            'pot_before': self.pot_before,
            'stack_before': self.stack_before
        }


@dataclass
class PlayerState:
    player_id: str
    name: str
    stack: int
    hole_cards: List[Card] = field(default_factory=list)
    status: PlayerStatus = PlayerStatus.ACTIVE
    total_bet: int = 0
    current_bet: int = 0
    is_dealer: bool = False
    position: int = 0
    agent_type: str = "human"
    elo_rating: float = 1200.0

    def to_dict(self, show_cards: bool = False) -> dict:
        return {
            'player_id': self.player_id,
            'name': self.name,
            'stack': self.stack,
            'hole_cards': [c.to_dict() for c in self.hole_cards] if show_cards else
                          [{'hidden': True} for _ in self.hole_cards],
            'status': self.status.value,
            'total_bet': self.total_bet,
            'current_bet': self.current_bet,
            'is_dealer': self.is_dealer,
            'position': self.position,
            'agent_type': self.agent_type
        }

    def reset_for_hand(self):
        self.hole_cards = []
        self.status = PlayerStatus.ACTIVE
        self.total_bet = 0
        self.current_bet = 0


@dataclass
class GameState:
    game_id: str
    stage: GameStage
    players: List[PlayerState]
    community_cards: List[Card]
    pot: int
    side_pots: List[Dict]
    current_player_idx: int
    dealer_idx: int
    small_blind: int
    big_blind: int
    min_raise: int
    last_raise: int
    action_history: List[ActionRecord]
    hand_number: int = 0
    current_bet: int = 0

    @property
    def active_players(self) -> List[PlayerState]:
        return [p for p in self.players if p.status == PlayerStatus.ACTIVE]

    @property
    def all_in_players(self) -> List[PlayerState]:
        return [p for p in self.players if p.status == PlayerStatus.ALL_IN]

    @property
    def in_hand_players(self) -> List[PlayerState]:
        return [p for p in self.players
                if p.status in (PlayerStatus.ACTIVE, PlayerStatus.ALL_IN)]

    @property
    def current_player(self) -> Optional[PlayerState]:
        if 0 <= self.current_player_idx < len(self.players):
            return self.players[self.current_player_idx]
        return None

    def get_legal_actions(self, player: PlayerState) -> List[Dict]:
        """Get legal actions with amounts for a player"""
        actions = []
        call_amount = self.current_bet - player.current_bet
        call_amount = min(call_amount, player.stack)

        # Can always fold (unless check is available)
        if call_amount > 0:
            actions.append({'action': PlayerAction.FOLD.value, 'amount': 0, 'min': 0, 'max': 0})

        # Check vs Call
        if call_amount == 0:
            actions.append({'action': PlayerAction.CHECK.value, 'amount': 0, 'min': 0, 'max': 0})
        elif call_amount < player.stack:
            actions.append({'action': PlayerAction.CALL.value, 'amount': call_amount,
                            'min': call_amount, 'max': call_amount})

        # Raise
        min_raise = self.current_bet + max(self.min_raise, self.big_blind)
        max_raise = player.stack + player.current_bet
        raise_amount = min_raise - player.current_bet

        if player.stack > call_amount and raise_amount <= player.stack:
            actions.append({
                'action': PlayerAction.RAISE.value,
                'amount': raise_amount,
                'min': raise_amount,
                'max': player.stack
            })

        # All-in
        if player.stack > 0:
            actions.append({'action': PlayerAction.ALL_IN.value, 'amount': player.stack,
                            'min': player.stack, 'max': player.stack})

        return actions

    def to_dict(self, perspective_player_id: Optional[str] = None) -> dict:
        return {
            'game_id': self.game_id,
            'stage': self.stage.value,
            'community_cards': [c.to_dict() for c in self.community_cards],
            'pot': self.pot,
            'side_pots': self.side_pots,
            'current_player_idx': self.current_player_idx,
            'current_bet': self.current_bet,
            'min_raise': self.min_raise,
            'hand_number': self.hand_number,
            'players': [p.to_dict(show_cards=perspective_player_id is None or
                                   p.player_id == perspective_player_id)
                        for p in self.players],
            'legal_actions': self.get_legal_actions(self.current_player)
            if self.current_player else [],
            'action_history': [a.to_dict() for a in self.action_history[-20:]]
        }


class PokerEngine:
    """
    Complete Texas Hold'em engine with:
    - Multi-player support (2-9 players)
    - Blind structure
    - Side pot calculation
    - All-in handling
    - Showdown resolution
    """

    def __init__(self, num_players: int = 6,
                 starting_stack: int = 10000,
                 small_blind: int = 50,
                 big_blind: int = 100):
        self.num_players = num_players
        self.starting_stack = starting_stack
        self.small_blind = small_blind
        self.big_blind = big_blind
        self.deck = Deck()
        self.state: Optional[GameState] = None

    def create_game(self, player_configs: List[Dict]) -> GameState:
        """Initialize a new game with given player configurations"""
        players = []
        for i, config in enumerate(player_configs):
            player = PlayerState(
                player_id=config.get('player_id', str(uuid.uuid4())),
                name=config.get('name', f'Player {i + 1}'),
                stack=config.get('stack', self.starting_stack),
                position=i,
                agent_type=config.get('agent_type', 'human'),
                elo_rating=config.get('elo_rating', 1200.0)
            )
            players.append(player)

        self.state = GameState(
            game_id=str(uuid.uuid4()),
            stage=GameStage.PREFLOP,
            players=players,
            community_cards=[],
            pot=0,
            side_pots=[],
            current_player_idx=0,
            dealer_idx=0,
            small_blind=self.small_blind,
            big_blind=self.big_blind,
            min_raise=self.big_blind,
            last_raise=self.big_blind,
            action_history=[],
            hand_number=0
        )

        self._start_new_hand()
        return self.state

    def _start_new_hand(self):
        """Start a new hand"""
        state = self.state
        state.hand_number += 1
        state.stage = GameStage.PREFLOP
        state.community_cards = []
        state.pot = 0
        state.side_pots = []
        state.min_raise = state.big_blind
        state.last_raise = state.big_blind
        state.current_bet = 0
        state.action_history = []

        # Reset players
        eligible = [p for p in state.players if p.stack > 0]
        for p in eligible:
            p.reset_for_hand()

        # Shuffle and deal
        self.deck.reset()
        self.deck.shuffle()

        # Move dealer button
        active_positions = [p.position for p in eligible]
        next_dealer_pos = active_positions[(active_positions.index(
            state.dealer_idx % len(eligible)) + 1) % len(eligible)] \
            if state.hand_number > 1 else 0
        state.dealer_idx = next_dealer_pos

        # Set dealer flag
        for p in state.players:
            p.is_dealer = (p.position == state.dealer_idx)

        # Deal hole cards
        for p in eligible:
            p.hole_cards = self.deck.deal(2)

        # Post blinds
        self._post_blinds(eligible)

    def _post_blinds(self, eligible: List[PlayerState]):
        """Post small and big blinds"""
        state = self.state
        n = len(eligible)

        if n == 2:
            # Heads up: dealer posts SB
            sb_idx = eligible.index(next(p for p in eligible if p.is_dealer))
            bb_idx = 1 - sb_idx
        else:
            dealer_pos = next((i for i, p in enumerate(eligible) if p.is_dealer), 0)
            sb_idx = (dealer_pos + 1) % n
            bb_idx = (dealer_pos + 2) % n

        sb_player = eligible[sb_idx]
        bb_player = eligible[bb_idx]

        # Post SB
        sb_amount = min(state.small_blind, sb_player.stack)
        sb_player.stack -= sb_amount
        sb_player.current_bet = sb_amount
        sb_player.total_bet += sb_amount
        state.pot += sb_amount

        # Post BB
        bb_amount = min(state.big_blind, bb_player.stack)
        bb_player.stack -= bb_amount
        bb_player.current_bet = bb_amount
        bb_player.total_bet += bb_amount
        state.pot += bb_amount

        state.current_bet = bb_amount

        # Record blind actions
        state.action_history.append(ActionRecord(
            sb_player.player_id, PlayerAction.SMALL_BLIND,
            sb_amount, state.stage, state.pot - sb_amount, sb_player.stack + sb_amount))
        state.action_history.append(ActionRecord(
            bb_player.player_id, PlayerAction.BIG_BLIND,
            bb_amount, state.stage, state.pot - bb_amount, bb_player.stack + bb_amount))

        # First to act preflop: UTG (after BB)
        if n == 2:
            state.current_player_idx = next(
                i for i, p in enumerate(state.players) if p.player_id == sb_player.player_id)
        else:
            state.current_player_idx = next(
                i for i, p in enumerate(state.players)
                if p.player_id == eligible[(bb_idx + 1) % n].player_id)

        # Mark all-in blinds
        if sb_player.stack == 0:
            sb_player.status = PlayerStatus.ALL_IN
        if bb_player.stack == 0:
            bb_player.status = PlayerStatus.ALL_IN

    def apply_action(self, action: PlayerAction, amount: int = 0) -> Tuple[GameState, Dict]:
        """Apply an action to the current game state"""
        state = self.state
        player = state.current_player

        if player is None or player.status != PlayerStatus.ACTIVE:
            raise ValueError("No active player to act")

        result = {'valid': True, 'message': '', 'hand_complete': False}

        call_amount = state.current_bet - player.current_bet
        pot_before = state.pot
        stack_before = player.stack

        if action == PlayerAction.FOLD:
            player.status = PlayerStatus.FOLDED

        elif action == PlayerAction.CHECK:
            if call_amount > 0:
                raise ValueError(f"Cannot check: call amount is {call_amount}")

        elif action == PlayerAction.CALL:
            actual_call = min(call_amount, player.stack)
            player.stack -= actual_call
            player.current_bet += actual_call
            player.total_bet += actual_call
            state.pot += actual_call
            if player.stack == 0:
                player.status = PlayerStatus.ALL_IN

        elif action == PlayerAction.RAISE:
            total_new_bet = player.current_bet + amount
            if total_new_bet <= state.current_bet:
                raise ValueError(f"Raise must be more than current bet {state.current_bet}")
            actual_amount = min(amount, player.stack)
            player.stack -= actual_amount
            player.current_bet += actual_amount
            player.total_bet += actual_amount
            state.pot += actual_amount
            state.last_raise = player.current_bet - state.current_bet
            state.current_bet = player.current_bet
            state.min_raise = state.last_raise
            if player.stack == 0:
                player.status = PlayerStatus.ALL_IN

        elif action == PlayerAction.ALL_IN:
            amount = player.stack
            if player.stack + player.current_bet > state.current_bet:
                state.last_raise = (player.stack + player.current_bet) - state.current_bet
                state.current_bet = player.stack + player.current_bet
                state.min_raise = max(state.min_raise, state.last_raise)
            player.current_bet += player.stack
            player.total_bet += player.stack
            state.pot += player.stack
            player.stack = 0
            player.status = PlayerStatus.ALL_IN

        # Record action
        state.action_history.append(ActionRecord(
            player.player_id, action, amount, state.stage, pot_before, stack_before))

        # Advance game
        hand_complete = self._advance_game()
        result['hand_complete'] = hand_complete

        return state, result

    def _advance_game(self) -> bool:
        """Advance game state, return True if hand is complete"""
        state = self.state

        # Check if only one player remains
        in_hand = state.in_hand_players
        if len(in_hand) == 1 and len([p for p in state.players if p.status == PlayerStatus.FOLDED]) > 0:
            self._award_pot([in_hand[0]])
            state.stage = GameStage.FINISHED
            return True

        # Check if betting round is complete
        active = state.active_players
        if self._betting_round_complete():
            return self._advance_stage()

        # Find next active player
        self._advance_to_next_player()
        return False

    def _betting_round_complete(self) -> bool:
        """Check if the current betting round is complete"""
        state = self.state
        active = state.active_players

        if len(active) == 0:
            return True

        # All active players have matched the current bet
        all_matched = all(
            p.current_bet == state.current_bet or p.stack == 0
            for p in active
        )

        # Everyone has had a chance to act (at least one action in this street)
        street_actions = [a for a in state.action_history
                          if a.stage == state.stage and
                          a.action not in (PlayerAction.SMALL_BLIND, PlayerAction.BIG_BLIND)]

        acted_this_round = set(a.player_id for a in street_actions)
        all_acted = all(p.player_id in acted_this_round for p in active)

        return all_matched and all_acted

    def _advance_stage(self) -> bool:
        """Move to next stage, return True if hand is complete"""
        state = self.state

        # Reset current bets
        for p in state.players:
            p.current_bet = 0
        state.current_bet = 0
        state.min_raise = state.big_blind

        if state.stage == GameStage.PREFLOP:
            state.community_cards.extend(self.deck.deal(3))
            state.stage = GameStage.FLOP
        elif state.stage == GameStage.FLOP:
            state.community_cards.extend(self.deck.deal(1))
            state.stage = GameStage.TURN
        elif state.stage == GameStage.TURN:
            state.community_cards.extend(self.deck.deal(1))
            state.stage = GameStage.RIVER
        elif state.stage == GameStage.RIVER:
            state.stage = GameStage.SHOWDOWN
            return self._resolve_showdown()

        # Check if only all-in players remain
        if not state.active_players:
            while len(state.community_cards) < 5:
                state.community_cards.extend(self.deck.deal(1))
                if len(state.community_cards) >= 5:
                    break
            return self._resolve_showdown()

        # Reset to first active player after dealer
        self._set_first_to_act()
        return False

    def _set_first_to_act(self):
        """Set first to act for post-flop (first active player left of dealer)"""
        state = self.state
        n = len(state.players)
        idx = (state.dealer_idx + 1) % n
        for _ in range(n):
            p = state.players[idx % n]
            if p.status == PlayerStatus.ACTIVE:
                state.current_player_idx = idx % n
                return
            idx += 1

    def _advance_to_next_player(self):
        """Move to next active player"""
        state = self.state
        n = len(state.players)
        idx = (state.current_player_idx + 1) % n
        for _ in range(n):
            p = state.players[idx]
            if p.status == PlayerStatus.ACTIVE:
                state.current_player_idx = idx
                return
            idx = (idx + 1) % n

    def _resolve_showdown(self) -> bool:
        """Resolve showdown and award pot"""
        state = self.state
        state.stage = GameStage.SHOWDOWN

        contestants = state.in_hand_players

        if len(contestants) == 1:
            self._award_pot(contestants)
            state.stage = GameStage.FINISHED
            return True

        # Evaluate hands
        results = []
        for player in contestants:
            hand_result = HandEvaluator.evaluate(
                player.hole_cards + state.community_cards)
            results.append((player, hand_result))

        # Sort by hand strength
        results.sort(key=lambda x: x[1], reverse=True)

        # Award pot (simplified - single pot)
        # In production, implement full side-pot logic
        winners = [r[0] for r in results if r[1] >= results[0][1]]
        self._award_pot(winners, results)

        state.stage = GameStage.FINISHED
        return True

    def _award_pot(self, winners: List[PlayerState], results: List = None):
        """Award pot to winners"""
        state = self.state
        share = state.pot // len(winners)
        remainder = state.pot % len(winners)

        for i, winner in enumerate(winners):
            award = share + (1 if i < remainder else 0)
            winner.stack += award

        state.pot = 0

    def start_new_hand(self) -> GameState:
        """Start a new hand (for tournaments)"""
        self._start_new_hand()
        return self.state
