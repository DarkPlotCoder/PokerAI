"""
Project Chimera - Card Engine
Complete playing card system with efficient bit representation
"""
from __future__ import annotations
import random
from enum import IntEnum
from typing import List, Optional, Tuple
from dataclasses import dataclass


class Suit(IntEnum):
    CLUBS = 0
    DIAMONDS = 1
    HEARTS = 2
    SPADES = 3

    @property
    def symbol(self) -> str:
        return ['♣', '♦', '♥', '♠'][self.value]

    @property
    def color(self) -> str:
        return 'red' if self in (Suit.DIAMONDS, Suit.HEARTS) else 'black'


class Rank(IntEnum):
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5
    SIX = 6
    SEVEN = 7
    EIGHT = 8
    NINE = 9
    TEN = 10
    JACK = 11
    QUEEN = 12
    KING = 13
    ACE = 14

    @property
    def symbol(self) -> str:
        symbols = {2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7',
                   8: '8', 9: '9', 10: 'T', 11: 'J', 12: 'Q', 13: 'K', 14: 'A'}
        return symbols[self.value]


@dataclass(frozen=True)
class Card:
    rank: Rank
    suit: Suit

    def __repr__(self) -> str:
        return f"{self.rank.symbol}{self.suit.symbol}"

    def __str__(self) -> str:
        return self.__repr__()

    @property
    def index(self) -> int:
        return (self.rank.value - 2) * 4 + self.suit.value

    @property
    def bit_mask(self) -> int:
        return 1 << self.index

    @classmethod
    def from_str(cls, s: str) -> 'Card':
        rank_map = {'2': Rank.TWO, '3': Rank.THREE, '4': Rank.FOUR, '5': Rank.FIVE,
                    '6': Rank.SIX, '7': Rank.SEVEN, '8': Rank.EIGHT, '9': Rank.NINE,
                    'T': Rank.TEN, 'J': Rank.JACK, 'Q': Rank.QUEEN, 'K': Rank.KING, 'A': Rank.ACE}
        suit_map = {'c': Suit.CLUBS, 'd': Suit.DIAMONDS, 'h': Suit.HEARTS, 's': Suit.SPADES,
                    '♣': Suit.CLUBS, '♦': Suit.DIAMONDS, '♥': Suit.HEARTS, '♠': Suit.SPADES}
        return cls(rank_map[s[0].upper()], suit_map[s[1].lower()])

    def to_dict(self) -> dict:
        return {
            'rank': self.rank.symbol,
            'suit': self.suit.symbol,
            'rank_value': self.rank.value,
            'suit_value': self.suit.value,
            'color': self.suit.color,
            'str': str(self)
        }


class Deck:
    def __init__(self):
        self.cards: List[Card] = []
        self.reset()

    def reset(self):
        self.cards = [Card(rank, suit)
                      for rank in Rank
                      for suit in Suit]

    def shuffle(self):
        random.shuffle(self.cards)

    def deal(self, n: int = 1) -> List[Card]:
        if len(self.cards) < n:
            raise ValueError(f"Not enough cards in deck: need {n}, have {len(self.cards)}")
        dealt = self.cards[:n]
        self.cards = self.cards[n:]
        return dealt

    def remove(self, cards: List[Card]):
        for card in cards:
            if card in self.cards:
                self.cards.remove(card)

    def __len__(self) -> int:
        return len(self.cards)
