"""
Project Chimera - Hand Evaluator
Advanced 7-card hand evaluation using optimized algorithms
Implements: Straight flush, quads, full house, flush, straight, trips, two pair, pair, high card
"""
from __future__ import annotations
from typing import List, Tuple, Dict
from collections import Counter
from itertools import combinations
from .cards import Card, Rank, Suit


class HandRank:
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9

    NAMES = {
        0: "High Card",
        1: "One Pair",
        2: "Two Pair",
        3: "Three of a Kind",
        4: "Straight",
        5: "Flush",
        6: "Full House",
        7: "Four of a Kind",
        8: "Straight Flush",
        9: "Royal Flush"
    }


class HandResult:
    def __init__(self, rank: int, tiebreaker: Tuple, cards: List[Card], name: str):
        self.rank = rank
        self.tiebreaker = tiebreaker
        self.cards = cards
        self.name = name

    def __gt__(self, other: 'HandResult') -> bool:
        if self.rank != other.rank:
            return self.rank > other.rank
        return self.tiebreaker > other.tiebreaker

    def __lt__(self, other: 'HandResult') -> bool:
        return other > self

    def __eq__(self, other: 'HandResult') -> bool:
        return self.rank == other.rank and self.tiebreaker == other.tiebreaker

    def __ge__(self, other: 'HandResult') -> bool:
        return not (self < other)

    def __le__(self, other: 'HandResult') -> bool:
        return not (self > other)

    def to_dict(self) -> dict:
        return {
            'rank': self.rank,
            'name': self.name,
            'tiebreaker': list(self.tiebreaker),
            'cards': [c.to_dict() for c in self.cards]
        }


class HandEvaluator:
    """
    Optimized Texas Hold'em hand evaluator.
    Evaluates best 5-card hand from up to 7 cards.
    """

    @staticmethod
    def evaluate(cards: List[Card]) -> HandResult:
        """Find the best 5-card hand from given cards"""
        if len(cards) < 5:
            raise ValueError(f"Need at least 5 cards, got {len(cards)}")

        best = None
        for combo in combinations(cards, 5):
            result = HandEvaluator._evaluate_five(list(combo))
            if best is None or result > best:
                best = result
        return best

    @staticmethod
    def _evaluate_five(cards: List[Card]) -> HandResult:
        """Evaluate exactly 5 cards"""
        ranks = sorted([c.rank.value for c in cards], reverse=True)
        suits = [c.suit.value for c in cards]
        rank_counts = Counter(ranks)

        is_flush = len(set(suits)) == 1
        is_straight, straight_high = HandEvaluator._check_straight(ranks)

        counts = sorted(rank_counts.values(), reverse=True)
        rank_groups = sorted(rank_counts.keys(),
                             key=lambda r: (rank_counts[r], r),
                             reverse=True)

        if is_straight and is_flush:
            if straight_high == 14:
                return HandResult(HandRank.ROYAL_FLUSH, (straight_high,), cards, "Royal Flush")
            return HandResult(HandRank.STRAIGHT_FLUSH, (straight_high,), cards, "Straight Flush")

        if counts[0] == 4:
            quad_rank = rank_groups[0]
            kicker = rank_groups[1]
            return HandResult(HandRank.FOUR_OF_A_KIND, (quad_rank, kicker), cards, "Four of a Kind")

        if counts[0] == 3 and counts[1] == 2:
            trip_rank = rank_groups[0]
            pair_rank = rank_groups[1]
            return HandResult(HandRank.FULL_HOUSE, (trip_rank, pair_rank), cards, "Full House")

        if is_flush:
            return HandResult(HandRank.FLUSH, tuple(ranks), cards, "Flush")

        if is_straight:
            return HandResult(HandRank.STRAIGHT, (straight_high,), cards, "Straight")

        if counts[0] == 3:
            trip_rank = rank_groups[0]
            kickers = sorted([r for r in ranks if r != trip_rank], reverse=True)
            return HandResult(HandRank.THREE_OF_A_KIND, (trip_rank, *kickers), cards, "Three of a Kind")

        if counts[0] == 2 and counts[1] == 2:
            pair1, pair2 = rank_groups[0], rank_groups[1]
            kicker = [r for r in ranks if r not in (pair1, pair2)][0]
            return HandResult(HandRank.TWO_PAIR, (max(pair1, pair2), min(pair1, pair2), kicker),
                              cards, "Two Pair")

        if counts[0] == 2:
            pair_rank = rank_groups[0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return HandResult(HandRank.ONE_PAIR, (pair_rank, *kickers), cards, "One Pair")

        return HandResult(HandRank.HIGH_CARD, tuple(ranks), cards, "High Card")

    @staticmethod
    def _check_straight(ranks: List[int]) -> Tuple[bool, int]:
        """Check if cards form a straight, return (is_straight, high_card)"""
        unique = sorted(set(ranks), reverse=True)
        if len(unique) < 5:
            return False, 0

        for i in range(len(unique) - 4):
            window = unique[i:i + 5]
            if window[0] - window[4] == 4:
                return True, window[0]

        # Check wheel (A-2-3-4-5)
        if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
            return True, 5

        return False, 0

    @staticmethod
    def equity_monte_carlo(hole_cards: List[Card],
                           board: List[Card],
                           num_opponents: int = 1,
                           simulations: int = 1000) -> Dict[str, float]:
        """
        Monte Carlo equity calculation
        Returns win, tie, loss probabilities
        """
        from .cards import Deck, Card, Rank, Suit

        wins = 0
        ties = 0
        losses = 0

        all_cards = [Card(rank, suit) for rank in Rank for suit in Suit]
        known_cards = set(hole_cards + board)
        remaining = [c for c in all_cards if c not in known_cards]

        cards_needed = (5 - len(board)) + (2 * num_opponents)

        if len(remaining) < cards_needed:
            simulations = min(simulations, 100)

        for _ in range(simulations):
            sample = random.sample(remaining, min(cards_needed, len(remaining)))

            new_board = board + sample[:5 - len(board)]
            opp_hands = []
            idx = 5 - len(board)
            for _ in range(num_opponents):
                if idx + 2 <= len(sample):
                    opp_hands.append(sample[idx:idx + 2])
                    idx += 2

            if not opp_hands:
                wins += 1
                continue

            my_result = HandEvaluator.evaluate(hole_cards + new_board)
            opp_results = [HandEvaluator.evaluate(h + new_board) for h in opp_hands]

            best_opp = max(opp_results)

            if my_result > best_opp:
                wins += 1
            elif my_result == best_opp:
                ties += 1
            else:
                losses += 1

        total = wins + ties + losses
        if total == 0:
            return {'win': 0.0, 'tie': 0.0, 'loss': 0.0, 'equity': 0.0}

        return {
            'win': wins / total,
            'tie': ties / total,
            'loss': losses / total,
            'equity': (wins + ties * 0.5) / total
        }

    @staticmethod
    def hand_strength(hole_cards: List[Card], board: List[Card]) -> float:
        """
        Calculate hand strength: probability of winning against one random opponent
        """
        if not board:
            return HandEvaluator._preflop_strength(hole_cards)

        result = HandEvaluator.equity_monte_carlo(hole_cards, board, 1, 500)
        return result['equity']

    @staticmethod
    def _preflop_strength(hole_cards: List[Card]) -> float:
        """Estimate preflop strength using standard lookup approximation"""
        ranks = sorted([c.rank.value for c in hole_cards], reverse=True)
        suited = len(set(c.suit for c in hole_cards)) == 1
        paired = ranks[0] == ranks[1]

        r1, r2 = ranks[0], ranks[1]

        # Simplified Chen formula approximation
        if paired:
            if r1 >= 14: return 0.85  # AA
            if r1 >= 13: return 0.82  # KK
            if r1 >= 12: return 0.80  # QQ
            if r1 >= 11: return 0.77  # JJ
            if r1 >= 10: return 0.75  # TT
            if r1 >= 9: return 0.72   # 99
            if r1 >= 8: return 0.69   # 88
            if r1 >= 7: return 0.66   # 77
            return 0.55 + (r1 - 2) * 0.02  # 22-66

        gap = r1 - r2
        base = 0.4 + (r1 + r2 - 4) * 0.008
        if suited:
            base += 0.03
        base -= gap * 0.02
        return max(0.3, min(0.82, base))


import random
