module.exports = {
  apps: [
    {
      name: 'chimera-backend',
      script: 'python3',
      args: '-m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1',
      cwd: '/home/user/chimera/backend',
      env: { NODE_ENV: 'production', PYTHONPATH: '/home/user/chimera/backend' },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    }
  ]
}
